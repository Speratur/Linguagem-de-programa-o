#include <stdio.h>

int main() {
	
    int n1, n2, n3, n4;
    float me;

    printf("===BEM-VINDO!===\n");
    printf("Vamos calcular a sua media?\n");

    printf("Por favor, digite suas notas, com apenas um espa�o entre elas: "); 
    scanf("%d %d %d %d", &n1, &n2, &n3, &n4);

    me = n1+n2+n3+n4;
    me = me/4;

    printf("Sua media: %.2f", me);
return 0;
}



#include <stdio.h>

int main() {
	
    char nome[100], curso[100];
    int idade, ano_nascimento;
    printf("=== PROGRAMA DE APRESENTA��O ===\n");
    
    printf("Digite seu nome completo: ");
    fgets(nome, sizeof(nome), stdin);
    printf("Digite sua idade: ");
    scanf("%d", &idade);

    printf("Digite seu curso: ");
    scanf(" %99[^\n]", curso); // serve para ler string com espa�os;
    
//calculo
    ano_nascimento = 2025 - idade;

//sa�da
    printf("\n=== Bem-vindo(a) ===\n");
    printf("Ol� %s\n", nome);
    printf("Voc� tem %d anos e estuda %s", idade, curso); 
    printf("Voc� tem aproximadamente %d\n", ano_nascimento);

return 0;
}

#include <stdio.h>

int main() {
	float ce, fa;

	printf("===CONVERSOR DE TEMPERATURA===\n");
	printf("Por favor, digite a temperatura em graus celsius: \n");
	scanf("%f", &ce);

	fa = ce * 1.8;
	fa = fa + 32;

	printf("===RESULTADO===\n");
	printf("%.2f graus celsius � %.1f em fahrenheit", ce, fa);

	return 0;
}

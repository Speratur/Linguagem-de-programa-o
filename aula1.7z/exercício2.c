#include <stdio.h>

int main() {
    int n1, n2;
    float re;
    
    printf("===BEM VINDO===\n");
    printf("Por favor, digite um n�mero inteiro: \n");
    scanf("%d", &n1);
    printf("digite um segundo n�mero: \n");
    scanf("%d", &n2);

    printf("\n--- SOMA ---\n");
    re = n1 + n2;
    printf("%d + %d � igual a %.2f\n", n1, n2, re);

    printf("\n--- SUBTRA��O ---\n");
    re = n1 - n2;
    printf("%d - %d � igual a %.2f\n", n1, n2, re);

    printf("\n--- MULTIPLICA��O ---\n");
    re = n1 * n2;
    printf("%d X %d � igual a %.2f\n", n1, n2, re);

    printf("\n--- DIVIS�O ---\n");
    if (n2 != 0) {
        re = (float) n1 / n2; // converte para float
        printf("%d / %d = %.2f\n", n1, n2, re);
    } else {
        printf("Nao eh possivel dividir por zero!!\n");
    }
    return 0;
}
